# WebGL Shadow Mapping Tutorial

## To read the tutorial

http://chinedufn.com/webgl-shadow-mapping-tutorial/

## To run locally

```
git clone https://github.com/chinedufn/webgl-shadow-mapping-tutorial
cd webgl-shadow-mapping-tutorial
npm install
npm run start
```

## License

MIT
